# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['grook']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['grook = grook.server:main']}

setup_kwargs = {
    'name': 'grook',
    'version': '0.1.0',
    'description': 'Group Book Web App',
    'long_description': None,
    'author': 'Nigel Gott',
    'author_email': 'nigel.gott@gmail.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
